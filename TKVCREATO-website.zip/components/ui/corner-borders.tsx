import { cn } from '@/lib/utils'

export function CornerBorders({ className }: { className?: string }) {
    // Corner borders disabled - return null to hide them across the entire website
    return null
}
