#!/bin/bash
# This script will be used to add the remaining 8 blog posts via the admin API
echo "Adding remaining blog posts via API..."
